//MVC Design Pattern -  Model class
//Ang John Syin
public abstract class MapItem{
    
	protected Coordinate coordinate;
    protected String imagePath;
	
	//Get the current coordinate of the mapitem           //Kevin Toh Huat Xiang
    public Coordinate getCoordinate(){
        return coordinate;
    }
	
	//Get the image path of the mapitem					  //Kevin Toh Huat Xiang
    public String getImagePath(){
        return imagePath;
    }
	
	//Set the coordinate of the mapitem
    public void setCoordinate(Coordinate coordinate){      //Ng Wee Fon
        this.coordinate = coordinate;
    }

	//Set the imagePath of the mapitem
    public void setImagePath(String imagePath){			   //Ng Wee Fon
        this.imagePath = imagePath;
    }
	
	//Check whether the coordinate is same or not          //Ang John Syin
    public boolean checkSamePlace(Coordinate coordinate){
        return (this.coordinate.isSame(coordinate));
    }
}
